export const ADD_CONTACT = 'ADD_CONTACT';
export const API_CONTACT = 'API_CONTACT';

const superagent = require('superagent');

export function addContact(contact) {
  return {
    type: ADD_CONTACT,
    payload: contact
  }
}

export function getFromApi() {
  return {
    type: API_CONTACT,
    payload: superagent.get('http://192.168.1.201:5001/rredux-api.php')
  }
}